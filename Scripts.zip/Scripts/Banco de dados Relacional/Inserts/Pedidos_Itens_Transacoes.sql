INSERT INTO pedidos (cliente_id, status, valor_total) VALUES (1, 'Processando', 8499.80) 
INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unitario) VALUES
(1, 1, 1, 7500.00),
(1, 3, 2, 499.90);
INSERT INTO transacoes_financeiras (pedido_id, metodo_pagamento, valor, status_pagamento) VALUES
(1, 'Cartão de Crédito', 8499.80, 'Aprovado');

INSERT INTO pedidos (cliente_id, status, valor_total) VALUES (2, 'Enviado', 3250.50) 
INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unitario) VALUES
(2, 2, 1, 3250.50);
INSERT INTO transacoes_financeiras (pedido_id, metodo_pagamento, valor, status_pagamento) VALUES
(2, 'PIX', 3250.50, 'Aprovado');


INSERT INTO pedidos (cliente_id, status, valor_total) VALUES (1, 'Entregue', 1200.00) 
INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unitario) VALUES
(3, 4, 1, 1200.00);
INSERT INTO transacoes_financeiras (pedido_id, metodo_pagamento, valor, status_pagamento) VALUES
(3, 'Boleto', 1200.00, 'Pendente');
