INSERT INTO clientes (nome, email, cpf) VALUES
('Marcelo Carvalho', 'marcelo.carvalho@gmail.com', '111.222.333-44'),
('Augusto Carrara', 'augusto_carrara@hotmail.com', '222.333.444-55'),
('Gerson Flamengo', 'gerson_flamengo@yahoo.com', '333.444.555-66');
