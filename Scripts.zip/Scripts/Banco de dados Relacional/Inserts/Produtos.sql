INSERT INTO produtos (nome, sku, preco_unitario, estoque, categoria) VALUES
('Notebook Dell', '00001', 7500.00, 50, 'Eletrônicos'),
('Iphone 14', '00002', 3250.50, 120, 'Eletrônicos'),
('Apple Pods', '00003', 499.90, 300, 'Acessórios'),
('Cadeira DT3', '00004', 1200.00, 80, 'Móveis');
