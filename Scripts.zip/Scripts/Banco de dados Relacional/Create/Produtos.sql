CREATE TABLE produtos (
    produto_id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    sku VARCHAR(100) NOT NULL UNIQUE,
    preco_unitario NUMERIC(10, 2) NOT NULL,
    estoque INT NOT NULL CHECK (estoque >= 0),
    categoria VARCHAR(100)
);
