CREATE TABLE transacoes_financeiras (
    transacao_id SERIAL PRIMARY KEY,
    pedido_id INT NOT NULL,
    metodo_pagamento VARCHAR(50),
    valor NUMERIC(10, 2) NOT NULL,
    status_pagamento VARCHAR(50) NOT NULL,
    data_transacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT fk_pedido_transacao
        FOREIGN KEY(pedido_id) 
        REFERENCES pedidos(pedido_id)
);
