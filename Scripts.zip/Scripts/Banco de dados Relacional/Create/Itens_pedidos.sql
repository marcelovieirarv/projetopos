CREATE TABLE itens_pedido (
    item_id SERIAL PRIMARY KEY,
    pedido_id INT NOT NULL,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario NUMERIC(10, 2) NOT NULL, -- Preço no momento da compra
    CONSTRAINT fk_pedido
        FOREIGN KEY(pedido_id) 
        REFERENCES pedidos(pedido_id),
    CONSTRAINT fk_produto
        FOREIGN KEY(produto_id) 
        REFERENCES produtos(produto_id)
);
